#ifndef _ARDUINO_SECRETS_H_
#define _ARDUINO_SECRETS_H_

#define SOCKET_IO_PORT              8080
#define SOCKET_IO_SERVER_URL        "192.168.2.30"

#define SOCKET_IO_AUTHORIZATION     "Authorization: 1234567890"

#endif /* ifndef _ARDUINO_SECRETS_H_ */
